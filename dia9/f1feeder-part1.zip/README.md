# F1FeederApp-Part1

## Getting Started

All you need to do is to clone this repository,


```
git clone https://github.com/raonibr/f1feeder-part1
cd f1feeder-part1
```

Then, install the dependencies:

```
npm install
```

Then, run the Application:

```
npm start
```

You can access your app at 

```
http://localhost:8000/app/
```